package com.epicode.amazon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonApplicationTests {

	@Test
	void contextLoads() {
	}

}
